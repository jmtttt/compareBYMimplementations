## ----knit_init, include = FALSE------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
  library("compareBYMimplementations")
  library("rstan")
  library("tidyverse")

## ----param---------------------------------------------------------------
load(file.path(find.package("compareBYMimplementations"), "data", "shape_GER.Rdata"))

basic_round <- do.call(what = rbind,
                       args = list(data.frame(region = "3",
                                              seed_risk = 1000+1:109),
                                   data.frame(region = "9",
                                              seed_risk = 1000+1:52),
                                   data.frame(region = "D",
                                              seed_risk = 1000+1:14)))
basic_round$region_ID <- 1:nrow(basic_round)


sim_param <- expand.grid(region_ID = basic_round$region_ID,
                         n_convolution = c(2, 4, 6),
                         rate_per_100k = 2^(0:7))

running_df <- dplyr::left_join(x = basic_round,
                               y = sim_param,
                               by = "region_ID")

running_df$seed_poisson <- running_df$seed_risk + 1000
running_df$region <- as.character(running_df$region)
running_df$simulation_ID <- 1:nrow(running_df)

print(as_tibble(running_df[(1:8)*475, ]))

## ----shapefile-----------------------------------------------------------
    my_running_ID <- 1234

    running_param = list(region        = running_df$region[my_running_ID],
                         ID            = my_running_ID,
                         seed_risk     = running_df$seed_risk[my_running_ID],
                         seed_poisson  = running_df$seed_poisson[my_running_ID],
                         n_convolution = running_df$n_convolution[my_running_ID],
                         rate_per_100k = running_df$rate_per_100k[my_running_ID])

    running_param <- append(x = running_param,
                            values = list(n = switch (running_param$region,
                                                      "9" = 96,
                                                      "3" = 46,
                                                      "D" = 402)))
    states_codes <- switch (running_param$region,
                            "9" = 9,
                            "3" = 3,
                            "D" = 1:16)

    shape_D <- artificial_risk(shapefile     = shape_GER[substr(shape_GER@data$region_ID, 1, 2) %in% sprintf("%02d", states_codes), ],
                               n_convolution = running_param$n_convolution,
                               rate_per_100k = running_param$rate_per_100k,
                               seed_risk     = running_param$seed_risk,
                               seed_poisson  = running_param$seed_poisson)

## ----calcout, results = "asis"-------------------------------------------
    knitr::kable(t(summarized_result))

